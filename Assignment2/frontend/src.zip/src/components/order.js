import 'bootstrap/dist/css/bootstrap.min.css'
import { Navbar, Nav, NavItem, NavDropdown, MenuItem ,Card,Button} from 'react-bootstrap';
import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Link,Redirect } from "react-router-dom"
import axios from 'axios';

export default class vendor extends Component{
    constructor(props)
    {
        super(props)
        this.state={
            id:this.props.match.params.id,
            arr:{},
            len1:0,
            product:{},
            len2:0
        }
        
        this.getDetails=this.getDetails.bind(this)
        this.edit=this.edit.bind(this)
    }
    componentDidMount(){
        this.getDetails();
        this.interval = setInterval(() => {
            this.getDetails();
          }, 3000);

    }
    getDetails(){
        axios.get('http://localhost:4000/order/'+this.state.id)
        .then(res=>{
            this.setState({arr:res.data})
            this.setState({len1:res.data.length})
            console.log('arr')
            console.log(this.state.arr)
        })
        axios.get('http://localhost:4000/list')
        .then(res=>{
            this.setState({product:res.data})
            this.setState({len2:res.data.length})

            console.log('product')
            console.log(this.state.product)
            this.render()
        })

    }
    edit(e,index){
        let inputvalue=prompt('Enter the quantity u want to order !')
        console.log('index array')
        console.log(index)
        if(inputvalue>(this.state.arr[index[0]].quantity+this.state.product[index[1]].quantity))
        {
            alert('Enter a valid input')
        }
        else{
            const q=this.state.arr[index[0]].quantity+this.state.product[index[1]].quantity
            // console.log('input')
            // console.log(inputvalue)
            let newarr=this.state.arr;
            newarr[index[0]].quantity=inputvalue
            this.setState({arr:newarr})
            
            
            
            // console.log('q')
            // console.log(q)
            
           
            newarr=this.state.product
            newarr[index[1]].quantity=q-inputvalue
            this.setState({product:newarr})
           
            const data={
                doc_id:this.state.product[index[1]]._id,
                quantity:q,
                value:inputvalue
            }
            const newdata={
                doc_id:this.state.arr[index[0]]._id,
                value:inputvalue
            }
            axios.post('http://localhost:4000/list/update', data)
            .then(res=>console.log(res.data))
            axios.post('http://localhost:4000/order/update',newdata)
            .then(res=>console.log(res.data))
        }
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    render()
    {   
        let array=[]
        
        let but=''
            for(var i=0;i<this.state.len1;i++){
                const index=[];
                let stat='Waiting'
                let k=0;
                for(;k<this.state.len2;k++)
                {
                    if(this.state.arr[i].pid==this.state.product[k]._id)
                    {
                        // console.log('shit')
                        break
                    }

                }
                if(k==this.state.len2)
                continue
                // console.log(k)
            if(this.state.product[k].quantity==0)
                stat='Placed'
            if(this.state.product[k].status=="Dispatched")
                stat='Dispatched'
            if(this.state.arr[i].cancel==1)
                stat='Canceled'
            index[0]=i;index[1]=k;
            if(stat=='Waiting')
                but=<Button variant="primary" onClick={(e)=>this.edit(e,index)}>Edit</Button>

                array.push(
                <div>
                <Card>
                <Card.Header>Order {i+1}</Card.Header>
                <Card.Body>
                    <Card.Title>Order Details</Card.Title>
                    <Card.Text>
                    Product name:{this.state.product[k].productname}
                    <br/>
                    Vendor name:{this.state.product[k].username}
                    <br/>
                    Quantity ordered:{this.state.arr[i].quantity}
                    <br/>
                    Status : {stat}
                    </Card.Text>
                    {but}
                </Card.Body>
                </Card>
                </div>
            )
        }
        
        return(
            <div>
            {array}
            </div>
        )
    }
}