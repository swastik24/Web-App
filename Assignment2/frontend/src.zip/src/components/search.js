import 'bootstrap/dist/css/bootstrap.min.css'
import { Navbar, Nav, NavItem, NavDropdown, MenuItem,InputGroup,FormControl,Button } from 'react-bootstrap';
import React, {Component} from 'react';
import {Table} from  'react-bootstrap' 
import { BrowserRouter as Router, Route, Link,Redirect } from "react-router-dom"
import axios from 'axios';

export default class Search extends Component{
    constructor(props){
        super(props)
        this.state={
            id:this.props.match.params.id,
            name:'',
            arr:{},
            error:'',
            length:''
        }
        this.onSubmit=this.onSubmit.bind(this)
        this.onChangename=this.onChangename.bind(this)
        this.createTable=this.createTable.bind(this)
        this.Order=this.Order.bind(this)
    }
    Order(e,info){
 
        const inputvalue=prompt('Quantity is :')
        const data={
            username:info.username,
            productname:this.state.name,
            price: info.price,
            quantity:info.quantity,
            value:inputvalue,
            doc_id:info._id
        }
       
        if(data.value>data.quantity)
        {
            alert('Input quantity is more than the  present quantity')
        }
        else
        {
            axios.post('http://localhost:4000/list/update', data)
            .then((res)=>{
              
                let arrnew=this.state.arr
                arrnew[info.index]['quantity']=info.quantity-inputvalue
                console.log(arrnew[info.index]['quantity'])
                this.setState({arr:arrnew})
                console.log(this.state.arr[info.index]['quantity'])
                this.render()
            })
            const  info_data={
                name:this.state.id,
                pid:info._id,
                quantity:inputvalue
            }
            console.log(info_data)
            axios.post('http://localhost:4000/order/add',info_data)
            .then(res=>console.log(res.data))
            
        }
    }
    onSubmit(e)
    {

        e.preventDefault();
        axios.get('http://localhost:4000/list/product/'+this.state.name)
        .then((res)=>{ 
     
        this.setState({length:res.data.length})
        this.setState({arr:res.data})

        
        })
        .then(()=>{
            (this.state.length>0)?(this.setState({error:''})):(this.setState({error:'* No Data with given product found'}))
        })
        .catch(err=> this.setState({error:'Please enter appropriate name (it should be a  string)'}))
      
    
   
    }
    onChangename(e)
    {
        this.setState({name:e.target.value})
        
    }
    createTable()
    {
        let table=[]
        let child=[]
        child.push(<th>{'Username'}</th>)
        child.push(<th>{'Price'}</th>)
        child.push(<th>{'Quantity'}</th>)
        child.push(<th>{'Order Button'}</th>)
        table.push(<tr>{child}</tr>)

        for(var i=0;i<this.state.length;i++)
        {
            let children=[]
            let info={}
            info['index']=i
            let remove=0
            for (var key in this.state.arr[i]){
                if(this.state.arr[i]['quantity']==0)
                {
                    remove=1
                }
                if(key!='productname' && key!='_id' && key!='__v' && key!='initialquantity' && key!='status')
                {
                    children.push(<td>{this.state.arr[i][key]}</td>)
                
                    info[key]=this.state.arr[i][key]
                }
                info[key]=this.state.arr[i][key]

            }
            if(remove==1)
            continue
       
            children.push(<td><Button variant="success" value={info} onClick={(e)=>this.Order(e,info)} >Order</Button></td>)
            table.push(<tr>{children}</tr>)

        }
        return table
    }
    render(){

        return(
            <div>
            <InputGroup className="mb-3">
            <FormControl
              placeholder="Recipient's username"
              aria-label="Recipient's username"
              aria-describedby="basic-addon2"
              onChange={this.onChangename}
              />
            <InputGroup.Append >
              <Button variant="outline-dark" onClick={this.onSubmit}>Search</Button>
             
            </InputGroup.Append>
          </InputGroup>
          <p>{this.state.error}</p>
           
            <Table responsive striped bordered hover variant="dark" striped bordered hover>
            {this.createTable()}
            </Table>
            </div>
        )
    }
}
