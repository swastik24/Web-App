import 'bootstrap/dist/css/bootstrap.min.css'
import { Navbar, Nav, NavItem, NavDropdown, MenuItem } from 'react-bootstrap';
import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Link,Redirect } from "react-router-dom"
import Search from  './search'
import Order from './order'
export default class vendor extends Component{

    render(){
        return(
            <Router>
            <div>
            <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
            
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav">
              <Nav className="mr-auto">
                
                <Nav.Link href={"/customer/"+this.props.match.params.id+"/search"}>Search Product</Nav.Link>
                <Nav.Link href={"/customer/"+this.props.match.params.id+"/order"}>Order</Nav.Link>

              
             </Nav>
              
            </Navbar.Collapse>
          </Navbar>
          <Route path={"/customer/:id/search"} component={Search}/>
          <Route path={"/customer/:id/order"} component={Order}/>

          </div>
          </Router>
        
        )
    }

}