import React, {Component} from 'react';
import { BrowserRouter as Router, Route, Link,Redirect } from "react-router-dom"
import Addproduct from './addproduct';
import Listproduct from './listproduct';
import Readytodispatch from './readytodispatch';
import Dispatched from './dispatched'

import 'bootstrap/dist/css/bootstrap.min.css'
import { Navbar, Nav, NavItem, NavDropdown, MenuItem } from 'react-bootstrap';
export default class vendor extends Component{
    render()
    {
        return(
            <Router>
            <div>
            <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
            
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav">
              <Nav className="mr-auto">
                
                <Nav.Link href={"/vendor/"+this.props.match.params.id+"/add"}>Add Product</Nav.Link>
                <Nav.Link href={"/vendor/"+this.props.match.params.id+"/list"}>Product List</Nav.Link>
                <Nav.Link href={"/vendor/"+this.props.match.params.id+"/ready"}>Ready To Dispatch</Nav.Link>
                <Nav.Link href={"/vendor/"+this.props.match.params.id+"/dispatched"}>Dispatched</Nav.Link>


             </Nav>
              
            </Navbar.Collapse>
          </Navbar>
        
            
            <Route path={"/vendor/:id/add"} component={Addproduct}/>
            <Route path={"/vendor/:id/list"} component={Listproduct}/>
            <Route path={"/vendor/:id/ready"} component={Readytodispatch}/>
            <Route path={"/vendor/:id/dispatched"} component={Dispatched}/>

            </div>
            </Router>
        )
    }
}